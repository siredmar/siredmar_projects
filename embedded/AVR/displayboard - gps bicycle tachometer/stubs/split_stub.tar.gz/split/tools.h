#ifndef _TOOLS_H_
#define _TOOLS_H_
#include <string.h>
#include <stdio.h>
#include <stdlib.h>


char *strtok_r_empty( char *p_str, const char *p_delim, char **pp_save );

#endif
